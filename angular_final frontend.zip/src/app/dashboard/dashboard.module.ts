import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { httpInterceptorProviders } from '../core/interceptors';

import { CoreModule } from '../core/core.module';

import { AuthService } from '../auth/services/auth.service';
import { FormsModule } from '@angular/forms';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { AboutComponent } from './components/about/about.component';

@NgModule({
  declarations: [DashboardComponent, AboutComponent],
  providers: [httpInterceptorProviders, AuthService],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    HttpClientModule,
    CoreModule,
    NgxDropzoneModule,
  ],
})
export class DashboardModule {}
