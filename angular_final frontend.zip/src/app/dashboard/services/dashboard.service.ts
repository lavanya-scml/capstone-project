import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  private tokenUrl =
    '/api/security/oauth/token?grant_type=client_credentials&client_id=33OkryzDZsKk8IShNMvXylRoYJ77j4yXk_2r9U7xsYfDbcFBAjiSfb9K9q-HfpAtqLdqnwE8hGMUWMiXQKC25oPV8lTgMoO8jxpIFoiT-R1-VoBQmaLHOA==&client_secret=lrFxI-iSEg-tb9Nekc5NKP0YmMNosx0iwQhR26Z4GNlzLg2ar-s2Aay5QQo1iYgIqTYOayMFB7IDVlCkb__Vb553WmjEi0r38RvTFq4zTolYahr1LmZlTnQNqjxNtD8y';

  private token: string = '';

  private addressUrl = '/api/places/geocode';
  constructor(private httpClient: HttpClient) {
    this.getToken();
  }

  getToken() {
    this.httpClient.post(this.tokenUrl, {}).subscribe((res: any) => {
      console.log(res);
      this.token = res.access_token;
      console.log(this.token);
    });
  }

  getAddress(address: string) {
    const url = this.addressUrl + '?itemCount=5&address=' + address;
    return this.httpClient.get(url, {
      headers: {
        Authorization: this.token,
      },
    });
  }

  addBackendAddress(data: any): Observable<any> {
    return this.httpClient.post('/api/auth/address', data);
  }
}
