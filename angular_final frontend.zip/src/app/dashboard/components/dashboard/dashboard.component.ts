import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/auth/models/login';
import { Register } from 'src/app/auth/models/register';
import { AuthService } from 'src/app/auth/services/auth.service';
import { DashboardService } from '../../services/dashboard.service';

//import { CreateProfileService } from 'src/app/profile-forms/services/create-profile.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  register: Register;
  login: Login;

  search = '';
  addresses = [];
  selectedAddress: any;
  files: File[] = [];
  backAddress: any;

  constructor(
    private authService: AuthService,
    private dashboardService: DashboardService
  ) {}

  ngOnInit(): void {
    // this.authService.loadUser().subscribe((res) => {
    //   console.log(JSON.stringify(res));
    //   this.register = res;
    //   localStorage.setItem('users', JSON.stringify(res));
    // });
    // (err) => console.log(err);
  }

  onChange() {
    console.log('changing');

    if (this.search.trim() && this.search.length > 3) {
      const addresses = this.search;
      this.dashboardService.getAddress(addresses).subscribe((res: any) => {
        console.log(res);

        if (res) {
          this.addresses = res.copResults;
        }
      });
    }
    if (!this.search) {
      this.addresses = [];
    }
  }

  onClickAddress(string: any) {
    console.log('inside click');
    this.backAddress = string;
    this.selectedAddress = string.formattedAddress;
    console.log(this.selectedAddress);
    if (this.selectedAddress) {
      this.search = this.selectedAddress;
      this.addresses = [];
    }
  }

  dragDrop() {
    var x = document.getElementById('drop');
    if (x.style.display === 'none') {
      x.style.display = 'block';
    } else {
      x.style.display = 'none';
    }
  }

  onSelect(event) {
    console.log(event);
    this.files.push(...event.addedFiles);
  }

  onRemove(event) {
    console.log(event);
    this.files.splice(this.files.indexOf(event), 1);
  }

  addAddress() {
    this.dashboardService
      .addBackendAddress(this.backAddress)
      .subscribe((res: any) => {
        console.log(res);
      });
  }
}
