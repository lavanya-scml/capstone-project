import { Alert } from './alert';

describe('Alert', () => {
  it('should create an instance', () => {
    expect(new Alert()).toBeTruthy();
  });
});
